<?php

session_start();

header("Access-Control-Max-Age: 3600");
header("Access-Control-Allow-Methods: GET, POST, PUT, DELETE");
header("Access-Control-Allow-Origin: *");
header("Content-Type: application/json; charset=UTF-8");
header("Access-Control-Allow-Headers: Content-Type, Access-Control-Allow-Headers, Authorization, X-Requested-With");

require_once "model/Msg.php";
require_once "model/Usuario.php";
require_once "configs/utils.php";
require_once "configs/methods.php";



if (isMetodo("POST")) {
    if (parametrosValidos($_POST, ["texto"])) {
        $texto = $_POST["texto"];
        $email = $_SESSION["email"];
        
        $pessoasSeparadas = explode(',', $_POST['usuarios'] );
        $email_user1= $pessoasSeparadas[0]; 
        $email_user2= $pessoasSeparadas[1];
        
        if (Usuario:: existeUsuarioEmail($email)) {
            if (Msg::cadastrar($email, $texto, $email_user1, $email_user2 )) {
               
           
               
               header("Location: Conversas.php");
               exit();
            } else {
                
                header("Location: Conversas.php");
                exit();
            }
        } 
    } 
}

