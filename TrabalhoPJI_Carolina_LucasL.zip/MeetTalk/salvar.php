<?php
session_start();

require_once('./configs/BancoDados.php');


require_once('./configs/utils.php');


require_once('./model/Imagem.php');

if (isMetodo("POST")) {
    define('TAMANHO_MAXIMO', (2 * 1024 * 1024));
    
    if (!isset($_FILES['foto']))
    {
        echo retorno('Selecione uma imagem');
        exit;
    }
    
    $foto = $_FILES['foto'];
    $nome = $foto['name'];
    $tipo = $foto['type'];
    $tamanho = $foto['size'];
    
   
    if(!preg_match('/^image\/(pjpeg|jpeg|png|gif|bmp)$/', $tipo))
    {
        echo ('Isso não é uma imagem válida');
        exit;
    }
    
  
    if ($tamanho > TAMANHO_MAXIMO)
    {
        echo ('A imagem deve possuir no máximo 2 MB');
        exit;
    }
    
    $email= $_SESSION["email"];
    $conteudo = file_get_contents($foto['tmp_name']);
    if (Imagem::existeFoto($email)){
        Imagem::altera($conteudo, $nome, $tipo, $tamanho, $email);
        header("Location: Perfil.php");
        exit();
    }else{
        Imagem::cadastrar($email, $nome, $conteudo, $tipo, $tamanho);
        header("Location: Perfil.php");
        exit();
    }
   
    
    
    
    
    

}