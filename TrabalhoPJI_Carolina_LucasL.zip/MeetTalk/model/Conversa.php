<?php
require_once __DIR__ . "/../configs/BancoDados.php";

class Conversa
{
    public static function cadastrar($email_user1, $email_user2)
    {
        $lista=[$email_user1, $email_user2];
        sort($lista);
        

        try {
            $conexao = Conexao::getConexao();
            $stmt = $conexao->prepare("INSERT INTO conversa (email_user1, email_user2) VALUES (?,?)");
            $stmt->execute([$lista[0], $lista[1]]);

            if ($stmt->rowCount() > 0) {
                return true;
            } else {
                return false;
            }
        } catch (Exception $e) {
            echo $e->getMessage();
            exit;
        }
    }


    public static function existeConversa($email_user1, $email_user2)
    {
        $lista=[$email_user1, $email_user2];
        sort($lista);
        
        try {
            $conexao = Conexao::getConexao();
            $stmt = $conexao->prepare("SELECT * from conversa where email_user1=? and email_user2=? ");
            $stmt->execute([$lista[0], $lista[1]]);


            if ($stmt->rowCount() > 0) {
                return true;
            } else {
                return false;
            }
        } catch (Exception $e) {
            echo $e->getMessage();
            exit;
        }
    }

    public static function msgConversa ($email_user1, $email_user2)
    {
        $lista=[$email_user1, $email_user2];
        sort($lista);
        
        try {
            $conexao = Conexao::getConexao();
            $stmt = $conexao->prepare("SELECT texto, data, email_enviou
            FROM mensagem 
            INNER JOIN conversa ON email_user1 = email_usuario1 and email_user2 = email_usuario2
            WHERE conversa.email_user1 = ?  and conversa.email_user2 = ? ");
            $stmt->execute([$lista[0], $lista[1]]);

            if ($stmt->rowCount() > 0) {
                $resultado=$stmt->fetchAll();
                return $resultado;
            } else {
                return false;
            }
        } catch (Exception $e) {
            echo $e->getMessage();
            exit;
        }
    }



    public static function conversaUsuario ($email)
    {
         
        try {
            
            $conexao = Conexao::getConexao();
            $stmt = $conexao->prepare("SELECT DISTINCT
            c.* FROM conversa c LEFT JOIN mensagem m ON (m.email_usuario1 = c.email_user1 AND m.email_usuario2 = c.email_user2)
            OR (m.email_usuario1 = c.email_user2 AND m.email_usuario2 = c.email_user1) WHERE c.email_user1 = ? OR c.email_user2 = ? ORDER BY m.data DESC;");
            $stmt->execute([$email, $email]);

          
            if ($stmt->rowCount() > 0) {
                $resultado=$stmt->fetchAll();
                $lista=[];
               

                foreach ($resultado as $conversa){
                
                  foreach ($conversa as $info){
                    if ($info != $email){
                        array_push($lista, $info);
                    }
                  }
                }       
               
                return $lista;
            } else {
                return false;
            }
        } catch (Exception $e) {
            echo $e->getMessage();
            exit;
        }
    }





}

