

<?php

require_once __DIR__ . "/../configs/BancoDados.php";
class Imagem
{
public static function cadastrar($email, $nome, $conteudo, $tipo, $tamanho)
    {

        try {
            $conexao = Conexao::getConexao();
            $stmt = $conexao->prepare('INSERT INTO fotos ( email, nome, conteudo, tipo, tamanho) VALUES (?, ?, ?, ?, ?)');
            $stmt->execute([$email, $nome, $conteudo, $tipo, $tamanho]);

            if ($stmt->rowCount() > 0) {
                return true;
            } else {
                return false;
            }
        } catch (Exception $e) {
            echo $e->getMessage();
            exit;
        }
    }


    public static function recupera($email)
    {
       
        try {
            $conexao = Conexao::getConexao();
            $stmt = $conexao->prepare("SELECT email, conteudo, tipo FROM fotos WHERE email = ?");
            $stmt->execute([$email]);

           
   
            if ($stmt->rowCount() > 0) {
                $resultado= $stmt->fetchObject();
               
                return $resultado;
            } else {
                echo "quero morrer2";
                return false;
            }
        } catch (Exception $e) {
            echo $e->getMessage();
            exit;
        }
    }


    public static function existeFoto($email)
    {
       
        try {
            $conexao = Conexao::getConexao();
            $stmt = $conexao->prepare("SELECT * FROM fotos WHERE email = ?");
            $stmt->execute([$email]);

           
   
            if ($stmt->rowCount() > 0) {
               
                return true;
            } else {
                
                return false;
            }
        } catch (Exception $e) {
            echo $e->getMessage();
            exit;
        }
    }


    public static function altera($conteudo, $nome, $tipo, $tamanho, $email)
    {
       
        try {
            $conexao = Conexao::getConexao();
            $stmt = $conexao->prepare("UPDATE fotos set conteudo = ?, nome =? , tipo=?, tamanho=?  WHERE email = ?");
            $stmt->execute([$conteudo, $nome, $tipo, $tamanho, $email]);

           
   
            if ($stmt->rowCount() > 0) {
               
               
                return true;
            } else {
               
                return false;
            }
        } catch (Exception $e) {
            echo $e->getMessage();
            exit;
        }
    }

}