<?php
require_once __DIR__ . "/../configs/BancoDados.php";

class Seguidores {

    public static function seguirUsuario($email_usuario, $email_seguidor)
    {
        try {
            $conexao = Conexao::getConexao();
            $stmt = $conexao->prepare('INSERT INTO seguidores (email_usuario, email_seguidor) VALUES (?,?)');
            $stmt->execute([$email_usuario, $email_seguidor]);

            if ($stmt->rowCount() > 0) {
                return true;
            } else {
                return false;
            }
        } catch (Exception $e) {
            echo $e->getMessage();
            exit;
        }
    }

    public static function QtdSeguindo($email_seguidor)
    {
        try {
            $conexao = Conexao::getConexao();
            $stmt = $conexao->prepare('SELECT COUNT(*) as "QtdSeguindo" FROM seguidores WHERE email_seguidor=?;');
            $stmt->execute([$email_seguidor]);

            if ($stmt->rowCount() > 0) {
                $resultado=$stmt->fetch();
                return $resultado;
            } else {
                return false;
            }
        } catch (Exception $e) {
            echo $e->getMessage();
            exit;
        }
    }

    public static function QtdSeguidores($email_usuario)
    {
        try {
            $conexao = Conexao::getConexao();
            $stmt = $conexao->prepare('SELECT COUNT(*) as "QtdSeguidores" FROM seguidores WHERE email_usuario=?;');
            $stmt->execute([$email_usuario]);

            if ($stmt->rowCount() > 0) {
                $resultado=$stmt->fetch();
                return $resultado;
            } else {
                return false;
            }
        } catch (Exception $e) {
            echo $e->getMessage();
            exit;
        }
    }

    public static function mostrarSeguidores($email_usuario)
    {
        try {
            $conexao = Conexao::getConexao();
            $stmt = $conexao->prepare('SELECT email_seguidor FROM seguidores WHERE email_usuario=?');
            $stmt->execute([$email_usuario]);
    
            if ($stmt->rowCount() > 0) {
                $resultado=$stmt->fetchAll();
               
                return $resultado;
            } else {
                return false;
            }    
            return $resultados;
        } catch (Exception $e) {
            echo $e->getMessage();
            exit;
        }
    }
    

    public static function mostrarSeguindo($email_seguidor)
    {
        try {
            $conexao = Conexao::getConexao();
            $stmt = $conexao->prepare('SELECT `email_usuario` FROM `seguidores` WHERE `email_seguidor`=?');
            $stmt->execute([$email_seguidor]);

            if ($stmt->rowCount() > 0) {
                $resultado=$stmt->fetchAll();
               
                return $resultado;
            } else {
                return false;
            }    
            return $resultados;
        } catch (Exception $e) {
            echo $e->getMessage();
            exit;
        }
    }

    public static function pararSeguir($email_usuario, $email_seguidor)
    {
        try {
            $conexao = Conexao::getConexao();
            $stmt = $conexao->prepare('DELETE FROM seguidores WHERE email_usuario=? and email_seguidor=?;');
            $stmt->execute([$email_usuario, $email_seguidor]);
    
            if ($stmt->rowCount() > 0) {
                return true;
            } else {
                return false;
            }
        } catch (Exception $e) {
            echo $e->getMessage();
            exit;
        }
    }
    

}

  
