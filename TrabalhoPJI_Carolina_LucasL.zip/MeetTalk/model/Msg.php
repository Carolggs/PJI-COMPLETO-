<?php
require_once __DIR__ . "/../configs/BancoDados.php";

class Msg
{
    public static function cadastrar($email_enviou, $texto,   $email_user1, $email_user2)
    {
        $lista=[$email_user1, $email_user2];
        sort($lista);
        echo $email_enviou;
        echo $texto;
        
        try {
            $conexao = Conexao::getConexao();
            $stmt = $conexao->prepare("INSERT INTO mensagem (email_enviou, texto, data,  email_usuario1, email_usuario2) VALUES (?,?, NOW(),?,?)");
            $stmt->execute([$email_enviou, $texto,  $lista[0], $lista[1]]);

            if ($stmt->rowCount() > 0) {
            
                return true;
            } else {
               
                return false;
            }
        } catch (Exception $e) {
            echo $e->getMessage();
            exit;
        }
    }

  





}