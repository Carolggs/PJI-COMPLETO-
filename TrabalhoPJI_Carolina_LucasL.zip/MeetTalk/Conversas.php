<?php
session_start();

require_once "model/Usuario.php";
require_once "model/Conversa.php";
require_once "configs/utils.php";
require_once "configs/methods.php";
require_once "model/Imagem.php";


?>


<!DOCTYPE html>
<html lang="pt-br">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/css/bootstrap.min.css" rel="stylesheet"
        integrity="sha384-1BmE4kWBq78iYhFldvKuhfTAU6auU8tT94WrHftjDbrCEXSU1oBoqyl2QvZ6jIW3" crossorigin="anonymous">
    <link rel="stylesheet" href="style.css">



    <title>Index</title>

    <style>
    body {
        background-color: #f4f7f6;
    }

    #elemento {
        width: 100%;
        /* height: 400px; */
        background-color: white;
        overflow: hidden;
        /* Para manter as dimensões visíveis */
    }

    .card {
        background: #fff;
        transition: .5s;
        border: 0;
        margin-bottom: 30px;
        border-radius: .55rem;
        position: relative;
        width: 100%;
        box-shadow: 0 1px 2px 0 rgb(0 0 0 / 10%);
    }

    .chat-app .people-list {
        width: 280px;
        position: absolute;
        left: 0;
        top: 0;
        padding: 20px;
        z-index: 7
    }

    .chat-app .chat {
        margin-left: 280px;
        border-left: 1px solid #eaeaea
    }

    .people-list {
        -moz-transition: .5s;
        -o-transition: .5s;
        -webkit-transition: .5s;
        transition: .5s
    }

    .people-list .chat-list li {
        padding: 10px 15px;
        list-style: none;
        border-radius: 3px
    }

    .people-list .chat-list li:hover {
        background: #efefef;
        cursor: pointer
    }

    .people-list .chat-list li.active {
        background: #efefef
    }

    .people-list .chat-list li .name {
        font-size: 15px
    }

    .people-list .chat-list img {
        width: 45px;
        border-radius: 50%
    }

    .people-list img {
        float: left;
        border-radius: 50%
    }

    .people-list .about {
        float: left;
        padding-left: 8px
    }

    .people-list .status {
        color: #999;
        font-size: 13px
    }

    .chat .chat-header {
        padding: 15px 20px;
        border-bottom: 2px solid #f4f7f6;
        
    }

    .chat .chat-header img {
        float: left;
        border-radius: 40px;
        width: 40px
    }

    .chat .chat-header .chat-about {
        float: left;
        padding-left: 10px
    }

    .chat .chat-history {
        padding: 20px;
        border-bottom: 2px solid #fff;

        padding-right: 10px;
        height: 350px;

    }

    .chat .chat-history ul {
        padding: 0;
        overflow-y: scroll;


        height: 300px;

        padding-right: 10px;
        display: flex;
        flex-direction: column-reverse;

    }

    .chat .chat-history ul li {
        list-style: none;
        margin-bottom: 30px;

    }

    .chat .chat-history ul li:last-child {
        margin-bottom: 0px
    }

    .chat .chat-history .message-data {
        margin-bottom: 15px
    }

    .chat .chat-history .message-data img {
        border-radius: 40px;
        width: 40px
    }

    .chat .chat-history .message-data-time {
        color: #434651;
        padding-left: 6px
    }

    .chat .chat-history .message {
        color: #444;
        padding: 18px 20px;
        line-height: 26px;
        font-size: 16px;
        border-radius: 7px;
        display: inline-block;
        position: relative
    }

    .chat .chat-history .message:after {
        bottom: 100%;
        left: 7%;
        border: solid transparent;
        content: " ";
        height: 0;
        width: 0;
        position: absolute;
        pointer-events: none;
        border-bottom-color: #fff;
        border-width: 10px;
        margin-left: -10px
    }

    .chat .chat-history .my-message {
        background: #efefef
    }

    .chat .chat-history .my-message:after {
        bottom: 100%;
        left: 30px;
        border: solid transparent;
        content: " ";
        height: 0;
        width: 0;
        position: absolute;
        pointer-events: none;
        border-bottom-color: #efefef;
        border-width: 10px;
        margin-left: -10px
    }

    .chat .chat-history .other-message {
        background: #e8f1f3;
        text-align: right
    }

    .chat .chat-history .other-message:after {
        o border-bottom-color: #e8f1f3;
        left: 93%
    }

    .chat .chat-message {
        padding: 20px
    }

    .online,
    .offline,
    .me {
        margin-right: 2px;
        font-size: 8px;
        vertical-align: middle
    }

    .online {
        color: #86c541
    }

    .offline {
        color: #e47297
    }

    .me {
        color: #1d8ecd
    }

    .float-right {
        float: right
    }

    .clearfix:after {
        visibility: hidden;
        display: block;
        font-size: 0;
        content: " ";
        clear: both;
        height: 0
    }

    #ulChat {

        height: 300px;
        overflow-y: scroll;
    }

    @media only screen and (max-width: 767px) {
        .chat-app .people-list {
            height: 465px;
            width: 100%;
            overflow-x: auto;
            background: #fff;
            left: -400px;
            display: none
        }

        .chat-app .people-list.open {
            left: 0
        }

        .chat-app .chat {
            margin: 0
        }

        .chat-app .chat .chat-header {
            border-radius: 0.55rem 0.55rem 0 0
        }

        .chat-app .chat-history {
            height: 300px;
            overflow-x: auto
        }
    }

    @media only screen and (min-width: 768px) and (max-width: 992px) {
        .chat-app .chat-list {
            height: 650px;
            overflow-x: auto
        }

        .chat-app .chat-history {
            height: 600px;
            overflow-x: auto
        }
    }

    @media only screen and (min-device-width: 768px) and (max-device-width: 1024px) and (orientation: landscape) and (-webkit-min-device-pixel-ratio: 1) {
        .chat-app .chat-list {
            height: 480px;
            overflow-x: auto
        }

        .chat-app .chat-history {
            height: calc(100vh - 350px);
            overflow-x: auto
        }
    }

    .container {
        margin-top: 20px;
        height: 100px;
    }

    button {
        border: none;
        padding: 0;
        background: none;
        cursor: pointer;
        /* Adicione outros estilos conforme necessário */
    }
    </style>

</head>

<body class="bg-secondary bg-gradient bg-opacity-10  overflow-hidden">

    <div class="d-flex   vh-100">
        <div class=" flex ">
            <div class="d-flex flex-column flex-shrink-0 p-3 text-white bg-dark vh-100 fs-5" style="width: 280px">
                <div class="profile-icon">
                    <?php
                    $email = $_SESSION["email"];
                    if (Imagem::existeFoto($email)){
                        $foto = Imagem::recupera($email);

                        echo "<div class='col-sm-6 col-md-4'>";
                            echo "<div class='thumbnail'>";
                            echo "<img  src='imagem.php?id=<?php echo $foto->email ?>' class='rounded-circle'
                    style='width: 70px; height:70px' />";
                    echo "</div>";
                echo "
            </div>";
            }else{
            echo "<img src='https://www.promoview.com.br/uploads/2017/04/b72a1cfe.png' alt='Generic placeholder image'
                class='rounded-circle' style='width: 70px; height:70px'>";
            }

            ?>
        </div>
        <p class="nomeUsuario ml-4">
            <?php 
                        $nome=Usuario::ExibirDados($_SESSION["email"]);
                        print_r($nome["nome"])
                    ?>
        </p>
        <hr class="mt-3 mb-5 ">
        <ul class="nav nav-pills flex-column mb-auto">
            <li class="mt-3">
                <a href="Index.php" class="nav-link text-white " aria-current="page">
                    <svg xmlns="http://www.w3.org/2000/svg" width="25" height="25" fill="currentColor"
                        class="bi bi-house-fill " viewBox="0 0 16 16">
                        <path
                            d="M8.707 1.5a1 1 0 0 0-1.414 0L.646 8.146a.5.5 0 0 0 .708.708L8 2.207l6.646 6.647a.5.5 0 0 0 .708-.708L13 5.793V2.5a.5.5 0 0 0-.5-.5h-1a.5.5 0 0 0-.5.5v1.293L8.707 1.5Z" />
                        <path d="m8 3.293 6 6V13.5a1.5 1.5 0 0 1-1.5 1.5h-9A1.5 1.5 0 0 1 2 13.5V9.293l6-6Z" />
                    </svg>
                    Página Inicial
                </a>
            </li>
            <li class="mt-5">
                <a href="Perfil.php" class="nav-link text-white">
                    <svg xmlns="http://www.w3.org/2000/svg" width="25" height="25" fill="currentColor"
                        class="bi bi-person-fill" viewBox="0 0 16 16">
                        <path d="M3 14s-1 0-1-1 1-4 6-4 6 3 6 4-1 1-1 1H3Zm5-6a3 3 0 1 0 0-6 3 3 0 0 0 0 6Z" />
                    </svg>
                    Perfil
                </a>
            </li>
            <li class="mt-5">
                <a href="Conversas.php" class="nav-link active">
                    <strong><svg xmlns="http://www.w3.org/2000/svg" width="25" height="25" fill="currentColor"
                            class="bi bi-chat-fill" viewBox="0 0 16 16">
                            <path
                                d="M8 15c4.418 0 8-3.134 8-7s-3.582-7-8-7-8 3.134-8 7c0 1.76.743 3.37 1.97 4.6-.097 1.016-.417 2.13-.771 2.966-.079.186.074.394.273.362 2.256-.37 3.597-.938 4.18-1.234A9.06 9.06 0 0 0 8 15z" />
                        </svg></strong>
                    Conversas
                </a>
            </li>
            <li class="mt-5">
                <a href="Pesquisa.php" class="nav-link text-white">
                    <svg xmlns="http://www.w3.org/2000/svg" width="20" height="20" fill="currentColor"
                        class="bi bi-search" viewBox="0 0 16 16">
                        <path
                            d="M11.742 10.344a6.5 6.5 0 1 0-1.397 1.398h-.001c.03.04.062.078.098.115l3.85 3.85a1 1 0 0 0 1.415-1.414l-3.85-3.85a1.007 1.007 0 0 0-.115-.1zM12 6.5a5.5 5.5 0 1 1-11 0 5.5 5.5 0 0 1 11 0z" />
                    </svg>
                    Pesquisa por Usuário
                </a>
            </li>
        </ul>
        <hr>

        <form class="ms-4" method="GET" action="usuario.php">
            <button class="btn btn-primary ms-5" type="submit" name="logout" value="logout">Logout</button>
        </form>
    </div>
    </div>











    <div class="p-2 flex-grow-1 mt-1 mb-5 ">
        <link href="https://maxcdn.bootstrapcdn.com/font-awesome/4.7.0/css/font-awesome.min.css" rel="stylesheet" />

        <div class="d-flex justify-content-center mt-2 ">
            <div class="container">
                <div class="row clearfix">
                    <div class="col-lg-12">
                        <div class="card chat-app">
                            <div id="plist" class="people-list">

                                <ul id="ulChat" class="list-unstyled chat-list mt-2 mb-0">


                                    <?php
                             
                                
                                    $email=$_SESSION["email"];
                                    if (Conversa::conversaUsuario($email) != false ) {
                                    $resultado= Conversa::conversaUsuario($email);
                                        foreach ($resultado as $user){
                                            $usuario=Usuario::  ExibirDados($user);

                                         

                                           $email= $usuario["email"];

                                           
                                          echo "<form method='POST' action='conversa.php' >";
                                          echo "<button type='submit'  name='entrarConversa' value='$email'>";
                                          echo "<li class='clearfix' >";
                                          echo "<div class='about'>";
                                          echo "<div class='name'>"  ;
                                               echo "<h6 id='usuarioConversa' class='mt-2'>";

if (Imagem::existeFoto($email)) {
    $foto = Imagem::recupera($email);
    echo "<div class='thumbnail' style='display: inline-block;'>";
    echo "<img src='imagemUser.php?email=" . urlencode($foto->email) . "' class='rounded-circle' style='width: 50px; height: 50px;' />";
    echo Usuario::ExibirDados($email)["nome"];

    echo "</div>";
} else {
    echo "<div class='thumbnail'>";
    echo  Usuario::ExibirDados($email)["nome"];

    echo "<img src='https://www.promoview.com.br/uploads/2017/04/b72a1cfe.png' alt='Generic placeholder image' class='rounded-circle' style='width: 50px; height: 50px;'>";

    echo "</div>";
}

echo "</h6>";

                                          echo "</div>";
                                          echo "</div>";
                                          echo "</li>";
                                          echo "</button>";
                                          echo "</form>";
                                          echo "<hr>"; 

                                    }
                                        } 
                                    
                             else {
                                echo "<h4 class='text-center mt-5'>"."</h4>";
                             }
                            
                            ?>




                                </ul>




                            </div>
                            <div class="chat">
                                <div class="chat-header clearfix">
                                    <div class="row">
                                        <div class="col-lg-6">

                                            <div class="chat-about">
                                                <?php
                                         if (empty($_SESSION['conversa'])){
                                            echo "<h6 id='usuarioConversa' class='m-b-0'>"."</h6>";
                                        }else{
                                            $pessoa;

                                            foreach ($_SESSION['conversa'] as $usuario){
                                                 if ($usuario != $_SESSION["email"]){
                                                     $pessoa= $usuario;
                                                 }
                                             
                                            }
                                            echo "<a href='javascript:void(0);' data-toggle='modal' data-target='#view_info'>";


                                          
                                            echo "</a>";
                                            echo "</div>";
                                            
                                            
                                     echo "<h6 id='usuarioConversa' class=' mt-2'>";
                                             $email1 = $pessoa;
                                            
                    if (Imagem::existeFoto($email1)){
                        $foto = Imagem::recupera($email1);

                        echo "<div class=''>";
                            echo "<div class='thumbnail' style='display: inline-block;' > ";
                            echo "<img src='imagemUser.php?email=" . urlencode($foto->email) . "'class='rounded-circle' style='width: 50px; height: 50px; ' />";

                           echo  Usuario::ExibirDados($pessoa)["nome"];
                                                echo "</div>";
                                            echo "</div>";
                                        }else{
                                            echo "<div class='thumbnail' style='display: inline-block;'>";
                                            echo  Usuario::ExibirDados($pessoa)["nome"];

                                        echo "<img src='https://www.promoview.com.br/uploads/2017/04/b72a1cfe.png'
                                            alt='Generic placeholder image' class='rounded-circle'
                                            style='width: 50px; height:50px'>";
                                            
                                            echo "</div>";
                                        }

                                    

                                        }
                                        echo "</h6>";

                                                               


                                        ?>


                                    </div>
                                </div>
                            </div>
                            <div id="elemento">

                                <div class="chat-history ">


                                    <?php
                               
                    
                               if (empty($_SESSION['conversa'])){
                                echo "<h1 class='text-center mt-5'>"."Escolha Conversa" ."</h1>";
                          }else{
                              
                            echo "<ul class='m-b-0' id='chat'>";
                            
                                    $email_user1=$_SESSION['conversa'][0];

                                    $email_user2=$_SESSION['conversa'][1];
                                   
                                    if (Conversa:: existeConversa($email_user1, $email_user2)) {
                                        
                                        if (Conversa::msgConversa($email_user1, $email_user2)) {
                                            $resultado=Conversa::msgConversa($email_user1, $email_user2);
                                           
                                          
                                            foreach ( array_reverse($resultado) as $u){

                                                if ($u["email_enviou"] == $_SESSION["email"]){
                                                  
                                                    echo "<li class='clearfix  '>";
                                                    
                                                    echo "<br>";
                                                    echo "<div class='message other-message float-right'>".  $u["texto"]. "<br>" . "<span class='message-data-time' style='font-size: 14px;'>". $u["data"]. "</span>"."</div>";
                                                    echo"</li>";
    
                                                    
                                                }else{
                                                    echo "<li class='clearfix  '>";
                                                    echo " <div class='message my-message '>" . $u["texto"] . "<br>".  "<span class='message-data-time'>". $u["data"]. "</span>" . "</div>";
                                                
                                        
                                                    echo"</li>";
                                                }
                                           
                                            }
                                        }
                                    } 
                                    
                                    echo "</ul>";
                                    echo "</div>";
                                    echo " </div>";
                                    $pessoas=$_SESSION['conversa'];
                                    $pessoasString = implode(',', $pessoas);
                                    
       
                                    echo '<div class="chat-message clearfix" style="display: flex; align-items: center;">';
                                    echo '<div class="input-group mb-3" style="margin-right: 10px;">';
                                        echo '<form method="POST" action="msg.php" style="display: flex; width: 100%;">';
                                            echo "<input type='text' class='form-control' placeholder='Digite uma mensagem' name='texto' required>";
                                            echo "<button class='btn btn-outline-primary' data-mdb-ripple-color='dark' style='z-index: 1;' name='usuarios' type='submit' value='$pessoasString'>";
                                                echo '<svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" fill="currentColor" class="bi bi-send" viewBox="0 0 16 16">';
                                                    echo '<path d="M15.854.146a.5.5 0 0 1 .11.54l-5.819 14.547a.75.75 0 0 1-1.329.124l-3.178-4.995L.643 7.184a.75.75 0 0 1 .124-1.33L15.314.037a.5.5 0 0 1 .54.11ZM6.636 10.07l2.761 4.338L14.13 2.576zm6.787-8.201L1.591 6.602l4.339 2.76 7.494-7.493Z"/>';
                                                echo '</svg>';
                                            echo '</button>';
                                        echo '</form>';
                                    echo '</div>';
                                echo '</div>';
                                
                               
                                                                
                                }
                                

                               ?>








                                </div>
                            </div>




                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
    </div>
    </div>
    </div>


</body>


</html>