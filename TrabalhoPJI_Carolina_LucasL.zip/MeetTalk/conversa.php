<?php

session_start();

header("Access-Control-Max-Age: 3600");
header("Access-Control-Allow-Methods: GET, POST, PUT, DELETE");
header("Access-Control-Allow-Origin: *");
header("Content-Type: application/json; charset=UTF-8");
header("Access-Control-Allow-Headers: Content-Type, Access-Control-Allow-Headers, Authorization, X-Requested-With");

require_once "model/Msg.php";
require_once "model/Usuario.php";
require_once "model/Conversa.php";
require_once "configs/utils.php";
require_once "configs/methods.php";




// criando uma conversa
if (isMetodo("POST")) {
    if (parametrosValidos($_POST, ["conversar"])) {
       
        $email_user1= $_SESSION["email"];
        $email_user2=$_POST["conversar"];

        if (!Conversa:: existeConversa($email_user1, $email_user2)) {
            Conversa:: cadastrar($email_user1, $email_user2);
            header("Location: Conversas.php");
            exit();
           
        } else{
            header("Location: Conversas.php");
            exit();
        }
    } else {
       // responder(400, ["status" => "Parâmetro 'texto' não foi encontrado para realizar o cadastro"]);
    }
    if (parametrosValidos($_POST, ["entrarConversa"])) {
        $email_user1= $_SESSION["email"];
        $email_user2=$_POST["entrarConversa"];
        $users=[$email_user1, $email_user2];
        $_SESSION['conversa']=$users;
 
        header("Location: Conversas.php");
        exit();

       

    }


   

}

