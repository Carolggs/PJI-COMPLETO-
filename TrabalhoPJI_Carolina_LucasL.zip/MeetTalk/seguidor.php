<?php

session_start();

header("Access-Control-Max-Age: 3600");
header("Access-Control-Allow-Methods: GET, POST, PUT, DELETE");
header("Access-Control-Allow-Origin: *");
header("Content-Type: application/json; charset=UTF-8");
header("Access-Control-Allow-Headers: Content-Type, Access-Control-Allow-Headers, Authorization, X-Requested-With");

require_once "model/Seguidores.php";
require_once "configs/utils.php";
require_once "configs/methods.php";

if (isMetodo("POST")) {

if (parametrosValidos($_POST, ["seguir"])) {
    $email_seguidor = $_SESSION["email"];
    $email_usuario = $_POST["seguir"];
    Seguidores::seguirUsuario($email_usuario, $email_seguidor);
    header("Location: UsuarioPesquisado.php?emailPessoa=$email_usuario");
    exit();


}

if (parametrosValidos($_POST, ["pararseguir"])) {
    $email_seguidor = $_SESSION["email"];
    $email_usuario = $_POST["pararseguir"];
    Seguidores::pararSeguir($email_usuario, $email_seguidor);
    header("Location: UsuarioPesquisado.php?emailPessoa=$email_usuario");
    exit();


}
if (parametrosValidos($_POST, ["verSeg"])) {
    $email_seguidor = $_SESSION["email"];
    $email_usuario = $_POST["verSeg"];
    Seguidores::pararSeguir($email_usuario, $email_seguidor);


}
}