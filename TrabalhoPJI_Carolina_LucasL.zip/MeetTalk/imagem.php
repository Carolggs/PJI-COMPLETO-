<?php
 session_start();


require_once('configs/BancoDados.php');

$pdo= Conexao::getConexao();
$email=$_SESSION["email"];
$stmt = $pdo->prepare('SELECT conteudo, tipo FROM fotos WHERE email = ?');

if ($stmt->execute([$email]))
{
    
    $foto = $stmt->fetchObject();
    
   
    if ($foto != null)
    {
        
        header('Content-Type: '. $foto->tipo);
        
        echo $foto->conteudo;
    }
}  



