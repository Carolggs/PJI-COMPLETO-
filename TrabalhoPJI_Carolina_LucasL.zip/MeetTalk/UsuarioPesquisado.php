<?php
session_start();

require_once "model/Usuario.php";
require_once "model/Seguidores.php";
require_once "configs/utils.php";
require_once "configs/methods.php";
require_once "model/Imagem.php";
$emailPessoa = urldecode($_GET["emailPessoa"]);

?>


<!DOCTYPE html>
<html lang="pt-br">
<style>
.modal {
    display: none;
    position: fixed;
    top: 0;
    left: 0;
    width: 100%;
    height: 100%;
    background-color: rgba(0, 0, 0, 0.7);
    z-index: 1;
}

#modal .modal-content {
    position: absolute;
    top: 50%;
    left: 50%;
    transform: translate(-50%, -50%);
    background-color: #fff;
    padding: 20px;
    border-radius: 15px;
    width: 400px;
    height: auto;
}

#modal2 .modal-content {
    position: absolute;
    top: 50%;
    left: 50%;
    transform: translate(-50%, -50%);
    background-color: #fff;
    padding: 20px;
    border-radius: 15px;
    width: 400px;
    height: auto;
}
#imagem2 {
  position: absolute;
}
</style>

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/css/bootstrap.min.css" rel="stylesheet"
        integrity="sha384-1BmE4kWBq78iYhFldvKuhfTAU6auU8tT94WrHftjDbrCEXSU1oBoqyl2QvZ6jIW3" crossorigin="anonymous">
    <link rel="stylesheet" href="style.css">



    <title>Index</title>


    <script>
    function mostrarFormulario() {
        const formulario = document.getElementById('meu-formulario');
        formulario.style.display = 'block';
    }

    function apagaFormulario() {
        const formulario = document.getElementById('meu-formulario');
        formulario.style.display = 'none';
    }
    

    function alterarTexto() {
        var botao = document.getElementById("meuBotao");
        botao.innerText = "Seguindo";
    }
    l

    function mostrarModal() {
        var modal = document.getElementById("modal");
        modal.style.display = "block";
    }
    function mostrarModal2() {
        var modal = document.getElementById("modal2");
        modal.style.display = "block";
    }


    function fecharModal() {
        var modal = document.getElementById("modal");
        modal.style.display = "none";
    }
    function fecharModal2() {
        var modal = document.getElementById("modal2");
        modal.style.display = "none";
    }

    </script>

</head>

<body class="bg-secondary bg-gradient bg-opacity-10 overflow-hidden ">

    <div class="d-flex align-items-xxl-stretch  ">
        <div class=" flex  vh-100">
            <div class="d-flex flex-column  flex-shrink-0 p-3 text-white bg-dark vh-100 fs-5" style="width: 280px ">
                <div class="profile-icon">
                <?php
                    $email = $_SESSION["email"];
                    if (Imagem::existeFoto($email)){
                        $foto = Imagem::recupera($email);

                        echo "<div class='col-sm-6 col-md-4'>";
                            echo "<div class='thumbnail'>";
                            echo "<img  src='imagem.php?id=<?php echo $foto->email ?>' class='rounded-circle' style='width: 70px; height:70px' />";    
                            echo "</div>";
                        echo "</div>";
                    }else{
                        echo "<img src='https://www.promoview.com.br/uploads/2017/04/b72a1cfe.png'
                        alt='Generic placeholder image' 
                        class='rounded-circle' style='width: 70px; height:70px'>";
                    }
                   
            ?>
                </div>
                <p class="nomeUsuario ml-4">
                    <?php 
                        $nome=Usuario::ExibirDados($_SESSION["email"]);
                        echo($nome["nome"])
                    ?>
                </p>
                <hr class="mt-3 mb-5 ">
                <ul class="nav nav-pills flex-column mb-auto ">
                    <li class="mt-3">
                        <a href="Index.php" class="nav-link text-white">
                            <svg xmlns="http://www.w3.org/2000/svg" width="25" height="25" fill="currentColor"
                                class="bi bi-house-fill" viewBox="0 0 16 16">
                                <path
                                    d="M8.707 1.5a1 1 0 0 0-1.414 0L.646 8.146a.5.5 0 0 0 .708.708L8 2.207l6.646 6.647a.5.5 0 0 0 .708-.708L13 5.793V2.5a.5.5 0 0 0-.5-.5h-1a.5.5 0 0 0-.5.5v1.293L8.707 1.5Z" />
                                <path d="m8 3.293 6 6V13.5a1.5 1.5 0 0 1-1.5 1.5h-9A1.5 1.5 0 0 1 2 13.5V9.293l6-6Z" />
                            </svg>
                            Página Inicial
                        </a>
                    </li>
                    <li class="mt-5">
                        <a href="Perfil.php" class="nav-link text-white" aria-current="page">
                            <svg xmlns="http://www.w3.org/2000/svg" width="25" height="25" fill="currentColor"
                                class="bi bi-person-fill" viewBox="0 0 16 16">
                                <path d="M3 14s-1 0-1-1 1-4 6-4 6 3 6 4-1 1-1 1H3Zm5-6a3 3 0 1 0 0-6 3 3 0 0 0 0 6Z" />
                            </svg>
                            Perfil
                        </a>
                    </li>
                    <li class="mt-5">
                        <a href="Conversas.php" class="nav-link text-white">
                            <strong><svg xmlns="http://www.w3.org/2000/svg" width="25" height="25" fill="currentColor"
                                    class="bi bi-chat-fill" viewBox="0 0 16 16">
                                    <path
                                        d="M8 15c4.418 0 8-3.134 8-7s-3.582-7-8-7-8 3.134-8 7c0 1.76.743 3.37 1.97 4.6-.097 1.016-.417 2.13-.771 2.966-.079.186.074.394.273.362 2.256-.37 3.597-.938 4.18-1.234A9.06 9.06 0 0 0 8 15z" />
                                </svg></strong>
                            Conversas
                        </a>
                    </li>
                    <li class="mt-5">
                        <a href="Pesquisa.php" class="nav-link text-white">
                            <svg xmlns="http://www.w3.org/2000/svg" width="20" height="20" fill="currentColor"
                                class="bi bi-search" viewBox="0 0 16 16">
                                <path
                                    d="M11.742 10.344a6.5 6.5 0 1 0-1.397 1.398h-.001c.03.04.062.078.098.115l3.85 3.85a1 1 0 0 0 1.415-1.414l-3.85-3.85a1.007 1.007 0 0 0-.115-.1zM12 6.5a5.5 5.5 0 1 1-11 0 5.5 5.5 0 0 1 11 0z" />
                            </svg>
                            Pesquisa por Usuário
                        </a>
                    </li>
                </ul>
                <hr>

                <form class="ms-4" method="GET" action="usuario.php">
                    <button class="btn btn-primary ms-5" type="submit" name="logout" value="logout">Logout</button>
                </form>
            </div>
        </div>

        <div class="flex-fill">

            <div class="card">
                <div class="rounded-top text-white d-flex flex-row" style="background-color: blue; height:130px;">
                    <div class="ms-4 mt-5 d-flex flex-column" style="width: 120px;">
                    <?php
                    if (Imagem::existeFoto($emailPessoa)){
                        $foto = Imagem::recupera($emailPessoa);

                        echo "<div class='col-sm-6 col-md-4'>";
                            echo "<div class='thumbnail'>";
                            echo "<img id='imagem2' style='width: 170px; height:170px'  class='rounded-circle' src='imagemUser.php?email=" . urlencode($foto->email) . "'/>";    
    
                            echo "</div>";
                        echo "</div>";
                    }else{
                       echo "<img id='imagem2' src='https://www.promoview.com.br/uploads/2017/04/b72a1cfe.png'
                        alt='Generic placeholder image' 
                        class='rounded-circle' style='width: 170px; height: 170px'>";
                    }
                   
            ?>

                    
                
                    </div>
                    <div class="ms-4" style="margin-top: 90px;">
                        <h3 class="nomeUsuario ml-4" style="margin-left: 40px;">
                            <?php 
                        $nome=Usuario::ExibirDados($emailPessoa);
                        print_r($nome["nome"])
                    ?>
                        </h3>

                    </div>
                </div>

                <div class="p-4 text-black" style="background-color: #f8f9fa;">



                    <div class="d-flex justify-content-end text-center py-2"> 
                        

                    <table>
                        <tr>
                        <td> 
                        <div>
                <form method="POST" action="seguidor.php">    
                        <button  class="btn btn-outline-primary" data-mdb-ripple-color="dark"
                            style="z-index: 1;" id="meuBotao" onclick="alterarTexto()" name="seguir"  value= "<?php echo $emailPessoa ?>" type="submit">
                            Seguir
                        </button>  
                        </form>                        
                        <div>
                             <div>
                             </td>
                             <td>  
                             <div>   
                             <form method="POST" action="seguidor.php">       
                             <button  class="btn btn-outline-primary" data-mdb-ripple-color="dark"
                            style="z-index: 1;" id="meuBotao"  name="pararseguir"  value= "<?php echo $emailPessoa ?>" type="submit">
                            Parar de Seguir
                        </button>
                        </form>                             
                    </div>    
                             </div>
                             </div>
                             </tr>
                             </td>
                             </table>
            
                        <div class="px-2">
                            <?php
                         $qtd=Seguidores::QtdSeguidores($emailPessoa);
                         echo "<p class='mb-1 h6'>". $qtd["QtdSeguidores"] ."</p>";
                         echo "<p class='small text-muted mb-0' onclick='mostrarModal()'>"."seguidores"."</p>";
                            ?>
                        </div>
                        <div>
                        <?php
                         $qtd=Seguidores::QtdSeguindo($emailPessoa);
                         echo "<p class='mb-1 h6'>". $qtd["QtdSeguindo"] ."</p>";
                         echo "<p class='small text-muted mb-0' onclick='mostrarModal2()'>"."seguindo"."</p>";
                            ?>
                        </div>
                    </div>
                </div>
                <div class="card-body p-2 text-black">
                    <div class="mb-1">

                        <div id="modal" class="modal" onclick="fecharModal()">
                            <div class="modal-content">
                                <?php
                                $email_usuario= $emailPessoa;
                                $resultado=Seguidores::mostrarSeguidores($email_usuario);
                                if ($resultado != null) {
                                    echo "<h1>Seguidores</h1>";

                                //print_r($resultado);
                                foreach ($resultado as $i => $user) {
                                  
                                $email_usuario = $user["email_seguidor"];

                                $dados= Usuario::ExibirDados($email_usuario);

                                    echo "<div class='user-info mt-3'>";
                                    echo "<p class='ms-2 bg-pink'>" . $dados["nome"] . "</p>";

                                    if (Imagem::existeFoto($email)) {
                                        $foto1 = Imagem::recupera($email);

                                        echo "<div class='ml-3 mb-3 mt-2'>";
                                        echo "<div class='thumbnail'>";
                                        echo "<img src='imagemUser.php?email=" . urlencode($foto1->email) . "' class='rounded-circle' style='width: 60px; height:60px'/>";
                                        echo "</div>";
                                        echo "</div>";
                                    } else {
                                        echo "<img src='https://www.promoview.com.br/uploads/2017/04/b72a1cfe.png' alt='Generic placeholder image' class='rounded-circle' style='width: 136px; height: 136px'>";
                                    }

                                    echo "</div>"; // Fechar a div 'user-info'
                                    echo "</div>"; // Fechar a div 'user-card'
                                }
                            } else {
                                echo "<h1>Não há seguidores</h1>";
                            }
                            ?>
                                </div>
                        </div>
                            </div>
                            </div>
                            <div class="card-body p-2 text-black">
                    <div class="mb-1">

                        <div id="modal2" class="modal" onclick="fecharModal2()">
                            <div class="modal-content">
                            <?php
                                $email_usuario= $emailPessoa;
                                $resultado=Seguidores::mostrarSeguindo($email_usuario);

                                //print_r($resultado);
                                if ($resultado != null) {
                                    echo "<h1>Seguindo</h1>";

                                foreach ($resultado as $i => $user) {
                                  
                                $email_usuario = $user["email_usuario"];

                                $dados= Usuario::ExibirDados($email_usuario);

                                    echo "<div class='user-info mt-3'>";
                                    echo "<p class='ms-2 bg-pink'>" . $dados["nome"] . "</p>";

                                    if (Imagem::existeFoto($email)) {
                                        $foto1 = Imagem::recupera($email);

                                        echo "<div class='ml-3 mb-3 mt-2'>";
                                        echo "<div class='thumbnail'>";
                                        echo "<img src='imagemUser.php?email=" . urlencode($foto1->email) . "' class='rounded-circle' style='width: 60px; height:60px'/>";
                                        echo "</div>";
                                        echo "</div>";
                                    } else {
                                        echo "<img src='https://www.promoview.com.br/uploads/2017/04/b72a1cfe.png' alt='Generic placeholder image' class='rounded-circle' style='width: 136px; height: 136px'>";
                                    }

                                    echo "</div>"; // Fechar a div 'user-info'
                                    echo "</div>"; // Fechar a div 'user-card'
                                }
                            } else {
                                echo "<h1>Não há seguindo</h1>";
                            }

                            ?>
                            </div>
                            
                            </div>
                            </div>
                            </div>
                        <?php
            $texto ="";
            $recupera=Usuario::recuperaMsg($emailPessoa);
            if ($recupera != false){
                $texto = $recupera["texto"];
            }else{
                $texto = "Não há mensagem do dia";
            }
            
            
             ?>


                        <p class="lead fw-normal  mt-1">Mensagem do Dia</p>
                    
                        <form method="POST" action="usuario.php">
                        <fieldset disabled>

                            <input name="texto" value="<?php echo $texto;?>" id="mensagemTextarea"
                                placeholder="Digite sua mensagem do dia" class="form-control " rows="2"
                                style="background-color: #f8f9fa; "></input>
        </fieldset>

                        </form>
                        <?php
            if (isset($_SESSION['erro'])) {
            echo '<p style="color: red;">' . $_SESSION['erro'] . '</p> ';
            unset($_SESSION['erro']); // Limpa a mensagem de erro para não exibi-la novamente após o refresh da página
          }
          ?>
<?php
                echo "<br>";
                $user= Usuario::infos($emailPessoa); 

                            
                $nome= $user["nome"];
                $emailP= $user["email"];
                $genero = $user["genero"];
                $data_nascimento = $user["data_nascimento"];
                $esporte = $user["esporte"];
                $estilo_musical = $user["estilo_musical"];
                $maior_qualidade = $user["maior_qualidade"];
                $maior_defeito = $user["maior_defeito"];
                $genero_literario = $user["genero_literario"];
                $genero_filme = $user["genero_filme"];
                $status_relacionamento = $user["status_relacionamento"];
                $religiao = $user["religiao"];
                $sexualidade = $user["sexualidade"];
                $pais = $user["pais"];

                echo "<h2 style='color: #0D6EFD; margin-bottom: 25px; margin-left: 20px;'>Características de $nome</h2>";
                echo  "<table>";
                echo  "<tr>";
                echo  "<td>"; 
                echo  "<div style='margin-left: 80px;'>"; 
                echo "<p><b>Gênero:</b> " . $genero . "</p>";
                echo "<p><b>Data de Nascimento:</b> " . $data_nascimento . "</p>";
                echo "<p><b>Esporte:</b> " . $esporte . "</p>";
                echo "<p><b>Estilo Musical:</b> " . $estilo_musical . "</p>";
                echo  "</div>"; 
                echo  "</td>";
                echo  "<td>"; 
                echo  "<td>"; 
                echo  "<div style='margin-left: 80px;'>"; 
                echo "<p><b>Maior Qualidade:</b> " . $maior_qualidade . "</p>";
                echo "<p><b>Maior Defeito:</b> " . $maior_defeito . "</p>";
                echo "<p><b>Gênero Literário:</b> " . $genero_literario . "</p>";
                echo "<p><b>Gênero de Filme:</b> " . $genero_filme . "</p>";
                echo  "</div>"; 
                echo  "</td>";
                echo  "<td>";  
                echo  "<div style='margin-left: 80px;'>"; 
                echo "<p><b>Status de Relacionamento:</b> " . $status_relacionamento . "</p>";
                echo "<p><b>Religião:</b> " . $religiao . "</p>";
                echo "<p><b>Sexualidade:</b> " . $sexualidade . "</p>";
                echo "<p><b>País:</b> " . $pais . "</p>";
                echo  "</div>"; 
                echo  "</tr>";
                echo  "</td>";
                echo  "</table>";


                echo "</div>";
                echo "</div>";


?>
                             

                        <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.1/dist/css/bootstrap.min.css"
                            rel="stylesheet"
                            integrity="sha384-4bw+/aepP/YC94hEpVNVgiZdgIC5+VKNBQNGCHeKRQN+PtmoHDEXuppvnDJzQIu9"
                            crossorigin="anonymous">
                        <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.1/dist/js/bootstrap.bundle.min.js"
                            integrity="sha384-HwwvtgBNo3bZJJLYd8oVXjrBZt8cqVSpeBNS5n7C8IVInixGAoxmnlMuBnhbgrkm"
                            crossorigin="anonymous"></script>

</body>

</html>